Program 1- Name 2024201043_q1.sh- To find the logs from access.file where the request method is POST and the HTTP status code is 404.
Description- 
The shell script is set to run in Bash. It uses 'grep' command to match the lines that have the string 'POST' in the input file access.log, which is in the same directory as the script. Then pipeline '|' is used to match another string ' 404 ' in the same file. Spaces are included in '404' before and after the match string to exclude erroneous results.

Program 2- Name 2024201043_q2.sh- To get the sum of powers from power_level.txt file
Description-
The shell script is set to run in Bash. This script uses 'awk' command to find the last column of each line, each column is separated by comma separator, so used -F',' option to separate the columns. Next, the action 'sum' is taken over column 4 values, then after END of first action, 'print' action is taken to print the value of sum. Next the input file name is given, to read the lines from.
